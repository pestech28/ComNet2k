import time
import requests
from bs4 import BeautifulSoup

def getusa(urlin, country, cityint, city):
    curtype = "missingno"
    curtemp = "999°"
    curdone = 0
    nxt1day = "NXT1"
    nxt1type = "missingno"
    nxt1temp = "999°"
    nxt1done = 0
    nxt2day = "NXT2"
    nxt2type = "missingno"
    nxt2temp = "999°"
    nxt2done = 0
    nxt3day = "NXT3"
    nxt3type = "missingno"
    nxt3temp = "999°"
    nxt3done = 0
    indexpath = country + "/" + cityint + "/index.html"
    response = requests.get(urlin)
    response.raise_for_status()
    try:
        soup = BeautifulSoup(response.text, "html.parser")
        curtypetmp = soup.find("p", class_="myforecast-current")
        curtype = curtypetmp.text.strip()
        curtemptmp = soup.find("p", class_="myforecast-current-lrg")
        curtemp = curtemptmp.text.strip() 
        periodname = [p.get_text(strip=True) for p in soup.find_all('p', class_='period-name')]
        shortdesc = [p.get_text(strip=True) for p in soup.find_all('p', class_='short-desc')]
        temphigh = [p.get_text(strip=True) for p in soup.find_all('p', class_='temp temp-high')]
        try:
            nxt1day = periodname[2]
            nxt1day = nxt1day.replace("Night", "")
            nxt1day = nxt1day.replace(" ", "<br>")
            nxt1day = nxt1day.replace(" ", "\n")
        except:
            print("Error 1")
        try:
            nxt1type = shortdesc[1]
            nxt1temp = temphigh[1]
            nxt1temp = nxt1temp.replace("High: ", "")
        except:
            print("Error 2")
        try:
            nxt2day = periodname[4]
            nxt2day = nxt2day.replace(" ", "<br>")
            nxt2day = nxt2day.replace(" ", "\n")
            nxt2day = nxt2day.replace("Night", "")
            nxt2type = shortdesc[3]
            nxt2temp = temphigh[2]
            nxt2temp = nxt2temp.replace("High: ", "")
        except:
            print("Error 3")
        try:
            nxt3day = periodname[6]
            nxt3day = nxt3day.replace(" ", "<br>")
            nxt3day = nxt3day.replace(" ", "\n")
            nxt3day = nxt3day.replace("Night", "")
            nxt3type = shortdesc[5]
            nxt3temp = temphigh[3]
            nxt3temp = nxt3temp.replace("High: ", "")
        except:
            print("Error 4")
        with open(indexpath, "w") as f:
            f.write('''<html>
                <head>
                    <title>Forecast.net: Your local weather</title>
                    <link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon">
                    <link rel="icon" href="../../favicon.ico" type="image/x-icon">
                    <meta charset="UTF-8">
                    <style>
                        body {
                            width: 100%;
                            height: 100%;
                            background-color: rgb(0,78,152);
                            overflow: auto;
                            overflow-x: hidden;
                            background-image: url(../../bg3.jpg);
                        }
                        h1, h2, h3 {
                            font-weight: 100;
                            color: white;
                            font-family: Arial, Helvetica, sans-serif;
                        }
                        a {
                            color: white;
                            font-family: Arial, Helvetica, sans-serif;
                        }
                        td {
                            padding-left: 15px;
                            text-align: center;
                        }
                        .mainui {
                            width: 580px;
                            height: 280px;
                            background-image: url(../../mainbg2.png);
                            display: block;
                        }
                    </style>
                </head>
                <body>
                    <center>
                        <div class="mainui">
                            <table class="wspace">
                                <tbody>''')
            f.write("<h1>" + city + "</h1><tr>\n")
            if ("Clear" in curtype):
                f.write('<td><h2>Now</h2><img src="../../sunny.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Sunny" in curtype):
                f.write('<td><h2>Now</h2><img src="../../sunny.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Fair" in curtype):
                f.write('<td><h2>Now</h2><img src="../../sunny.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Some Clouds" in curtype):
                f.write('<td><h2>Now</h2><img src="../../partcloud.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("A Few Clouds" in curtype):
                f.write('<td><h2>Now</h2><img src="../../partcloud.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Mostly Cloudy" == curtype):
                f.write('<td><h2>Now</h2><img src="../../partcloud.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Partly" in curtype):
                f.write('<td><h2>Now</h2><img src="../../partcloud.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if (curtype == "Cloudy"):
                f.write('<td><h2>Now</h2><img src="../../cloudy.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Rain" in curtype):
                f.write('<td><h2>Now</h2><img src="../../rain.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Shower" in curtype):
                f.write('<td><h2>Now</h2><img src="../../rain.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Thunder" in curtype):
                f.write('<td><h2>Now</h2><img src="../../thunder.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Thunderstorm" in curtype):
                f.write('<td><h2>Now</h2><img src="../../thunder.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Snow" in curtype):
                f.write('<td><h2>Now</h2><img src="../../snow.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if ("Blizard" in curtype):
                f.write('<td><h2>Now</h2><img src="../../snow.png" height="96"><br><h3>' + curtemp + "</h3></td>")
                curdone = 1
            if (curdone == 0):
                f.write('<td><h2>Now</h2><img src="../../missingno.png" height="96"><br><h3>999°</h3></td>')
            f.write('\n')
            if ("Clear" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Sunny" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Fair" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Some Clouds" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("A Few Clouds" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Mostly Cloudy" == nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Partly" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if (nxt1type == "Cloudy"):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../cloudy.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Rain" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../rain.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Shower" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../rain.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Thunder" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../thunder.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Thunderstorm" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../thunder.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Snow" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../snow.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if ("Blizard" in nxt1type):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../snow.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
                nxt1done = 1
            if (nxt1done == 0):
                f.write('<td><h2>' + nxt1day + '</h2><img src="../../missingno.png" height="96"><br><h3>' + nxt1temp + "</h3></td>")
            f.write('\n')
            if ("Clear" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Sunny" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Fair" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Some Clouds" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("A Few Clouds" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Mostly Cloudy" == nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Partly" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if (nxt2type == "Cloudy"):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../cloudy.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Rain" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../rain.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Shower" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../rain.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Thunder" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../thunder.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Thunderstorm" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../thunder.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Snow" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../snow.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if ("Blizard" in nxt2type):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../snow.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
                nxt2done = 1
            if (nxt2done == 0):
                f.write('<td><h2>' + nxt2day + '</h2><img src="../../missingno.png" height="96"><br><h3>' + nxt2temp + "</h3></td>")
            f.write('\n')
            if ("Clear" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Sunny" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Fair" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../sunny.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Some Clouds" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("A Few Clouds" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Mostly Cloudy" == nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Partly" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../partcloud.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if (nxt3type == "Cloudy"):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../cloudy.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Rain" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../rain.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Shower" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../rain.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Thunder" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../thunder.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Thunderstorm" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../thunder.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Snow" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../snow.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if ("Blizard" in nxt3type):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../snow.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
                nxt3done = 1
            if (nxt3done == 0):
                f.write('<td><h2>' + nxt3day + '</h2><img src="../../missingno.png" height="96"><br><h3>' + nxt3temp + "</h3></td>")
            f.write('\n')
            f.write('''</tr>
                            </tbody>
                        </table>
                    </div>
                </center>
            </body>
        </html>''') 
            f.close()
    except:
        print("Failed to download creating dummy file")
        with open(indexpath, "w") as f:
            f.write('''<html>
    <head>
        <title>Forecast.net: Your local weather</title>
        <link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon">
        <link rel="icon" href="../../favicon.ico" type="image/x-icon">
        <meta charset="UTF-8">
        <style>
            body {
                width: 100%;
                height: 100%;
                background-color: rgb(0,78,152);
                overflow: auto;
                overflow-x: hidden;
                background-image: url(../../bg3.jpg);
            }
            h1, h2, h3 {
                font-weight: 100;
                color: white;
                font-family: Arial, Helvetica, sans-serif;
            }
            a {
                color: white;
                font-family: Arial, Helvetica, sans-serif;
            }
            td {
                padding-left: 15px;
                text-align: center;
            }
            .mainui {
                width: 580px;
                height: 280px;
                background-image: url(../../mainbg2.png);
                display: block;
            }
        </style>
    </head>
    <body>
        <center>
            <div class="mainui">
                <table class="wspace">
                    <tbody>
                        <h1>CITY</h1>
                        <tr>
                            <td>
                                <h2>Now</h2>
                                <br>
                                <img src="../../missingno.png" height="96">
                                <br>
                                <h3>999°</h3>
                            </td>
                            <td>
                                <h2>NXT1</h2>
                                <br>
                                <img src="../../missingno.png" height="96">
                                <br>
                                <h3>999°</h3>
                            </td>
                            <td>
                                <h2>NXT2</h2>
                                <br>
                                <img src="../../missingno.png" height="96">
                                <br>
                                <h3>999°</h3>
                            </td>
                            <td>
                                <h2>NXT3</h2>
                                <br>
                                <img src="../../missingno.png" height="96">
                                <br>
                                <h3>999°</h3>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </center>
    </body>
</html>''')
        f.close()

    
    
    
print("Forecast Grabber")
print("Version 1.0")
print("2026-07-03")
try:
    while True:
        print("Downloading Boston MA Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=42.359&lon=-71.0586", "us", "bos", "Boston, MA")
        print("Finished")
        time.sleep(5)
        print("Downloading Cupertino CA Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=37.3193&lon=-122.0293", "us", "cup", "Cupertino, CA")
        print("Finished")
        time.sleep(5) 
        print("Downloading Dallas TX Weather",)
        print("Compiling webpage")
        getusa("http://forecast.weather.gov/MapClick.php?lat=32.778&lon=-96.7962", "us", "dal", "Dallas, TX")
        print("Finished")
        time.sleep(5)  
        print("Downloading Des Moines IA Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=41.5393&lon=-93.6586", "us", "des", "Des Moines, IA")
        print("Finished")
        time.sleep(5)  
        print("Downloading Houston TX Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=29.7608&lon=-95.3695", "us", "hou", "Houston, TX")
        print("Finished")
        time.sleep(5)  
        print("Downloading Miami FL Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=25.9272&lon=-80.2285", "us", "mia", "Miami, FL")
        print("Finished")
        time.sleep(5)  
        print("Downloading New York NY Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=40.6398&lon=-73.7787", "us", "nyc", "New York, NY")
        print("Finished")
        print("Downloading Pheonix AZ Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=34.4584&lon=-112.4482", "us", "phx", "Pheonix, AZ")
        print("Finished")
        time.sleep(5)  
        print("Downloading Springfield MA Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=42.1021&lon=-72.5858", "us", "sfm", "Springfield, MA")
        print("Finished")
        time.sleep(5)  
        print("Downloading St. Louis MO Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=38.6405&lon=-90.4434", "us", "stl", "St, Louis, MO")
        print("Finished")
        time.sleep(5)  
        print("Downloading Washington DC Weather",)
        print("Compiling webpage")
        getusa("https://forecast.weather.gov/MapClick.php?lat=38.890370000000075&lon=-77.03195999999997", "us", "wdc", "Washington DC")
        print("Finished")
        time.sleep(5)  
        print("Waiting")
        time.sleep(1800)  
except:
    print("Error has occured")
