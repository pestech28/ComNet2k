function getrestext() {
    var currentUrl = window.location.href;
    var result = currentUrl.replace("http://google.com/img/search/?q=", "");
    result = result.replace("&btnG=Google+Search", "");
    result = result.replace(/&btnG=Google([+\s]|%20)Image([+\s]|%20)Search/gi, "");
    result = result.replace(/\+/g, " ");
    result = result.replace(/&sa=I%27m Feeling Lucky/g, "");
    result = result.replace(/&btnI=I%27m Feeling Lucky/g, "");
    result = result.replace(/%20/g, " ");
    return result;
}


function addres(result) {
    var searchbox = document.getElementById("searchbox");
    var searchtext = document.getElementById("searchtext");
    var imgurl = document.getElementById("imgurl");
    comphref = "../../search/?q=" + result;
    compimghref = "../img/search/?q=" + result;
    weburl.href = comphref
    searchbox.href = comphref;
    searchbox.value = result;
    searchtext.innerHTML = result;
    imgurl.href = compimghref;
    titlecomp = "Google Image Search - " + result;
    document.title = titlecomp;
} 

function findres(db, result) {
    var main = document.getElementById("main");
    var restext = document.getElementById("restext");
    var query = result.replace(/^\s+|\s+$/g, "").toLowerCase();
    var restotal = 0;
    var htmlBuffer = ""; 
    var restextcomp = ""; 
    if (query === "") {
        restextcomp = '<font face="arial,sans-serif" size="-1" color="white">Results: <b>0</b> in 0.486 sec</font>';
        htmlBuffer = "<tr><td style='font-family:arial,sans-serif; font-size:small; padding:15px 0;'>" +
                     "<p>Your search - <b>" + result + "</b> - did not match any documents.</p>" +
                     "<p style='margin-top:15px;'>Suggestions:</p>" +
                     "<ul style='margin-left:20px;'>" +
                     "<li>Make sure all words are spelled correctly.</li>" +
                     "<li>Try different keywords.</li>" +
                     "<li>Try more general keywords.</li>" +
                     "<li>Try fewer keywords.</li>" +
                     "</ul>" +
                     "</td></tr>";
                     
        if (restext) { restext.innerHTML = restextcomp; }
        if (main) { main.innerHTML = "<table border='0' cellpadding='2' cellspacing='0'><tbody>" + htmlBuffer + "</tbody></table>"; }
        return;
    }
    var isBrainrot = 0;
    var brainrotKeywords = ["ai", "ai slop", "skibidi", "skibidi toilet", "skibidi sigma"];
    for (var k = 0; k < brainrotKeywords.length; k++) {
        if (brainrotKeywords[k] === query) {
            isBrainrot = 1;
            break;
        }
    }
    if (isBrainrot === 1) {
        restextcomp = '<font face="arial,sans-serif" size="-1" color="white">Results: <b>0</b> in 0.486 sec</font>';
        htmlBuffer = "<tr><td style='font-family:arial,sans-serif; font-size:small; padding:15px 0;'>" +
                     "<p>Your search - <b>AI Slop</b> - did not match any documents.</p>" +
                     "<p style='margin-top:15px;'>Suggestions:</p>" +
                     "<ul style='margin-left:20px;'>" +
                     "<li>Make sure you avoid brainrot.</li>" +
                     "<li>Try touching grass.</li>" +
                     "<li>Try to learn to code.</li>" +
                     "<li>Try to talk to a human.</li>" +
                     "</ul>" +
                     "</td></tr>";
                     
        if (restext) { restext.innerHTML = restextcomp; }
        if (main) { main.innerHTML = "<table border='0' cellpadding='2' cellspacing='0'><tbody>" + htmlBuffer + "</tbody></table>"; }
        return;
    }
    for (var i = 0; i < db.length; i++) {
        if (db[i] && db[i][3]) {
            var tags = db[i][3].toLowerCase();
            if (tags.indexOf(query) !== -1) {
                
                var imgUrl = db[i][0];
                var webUrl = db[i][1];
                var imgName = db[i][2];
                if (restotal % 4 === 0) {
                    htmlBuffer += "<tr>";
                }
                
                restotal++;
                htmlBuffer += "<td align='center' valign='bottom' width='25%' style='font-family:arial,sans-serif; padding:15px 10px;'>" +
                              "<a href='" + imgUrl + "' target='_blank'>" +
                              "<img src='" + imgUrl + "' width='120' height='120' border='1' style='border-color:#3366cc; margin-bottom:6px;' alt='Result'><br>" +
                              "</a>" +
                              "<a href='" + webUrl + "' style='color:#008000; font-size:10pt; text-decoration:underline;'>" + webUrl + "</a><br>" + 
                              "<span style='color:#000000; font-size:10pt;'> " + imgName + "</span>" +
                              "</td>";
                if (restotal % 4 === 0) {
                    htmlBuffer += "</tr>";
                }
            }
        }
    }
    if (restotal > 0 && restotal % 4 !== 0) {
        htmlBuffer += "</tr>";
    }
    if (restotal === 0) {
        restextcomp = '<font face="arial,sans-serif" size="-1" color="white">Results: <b>0</b> in 0.486 sec</font>';
        htmlBuffer = "<tr><td style='font-family:arial,sans-serif; font-size:small; padding:15px 0;'>" +
                     "<p>Your search - <b>" + result + "</b> - did not match any documents.</p>" +
                     "<p style='margin-top:15px;'>Suggestions:</p>" +
                     "<ul style='margin-left:20px;'>" +
                     "<li>Make sure all words are spelled correctly.</li>" +
                     "<li>Try different keywords.</li>" +
                     "<li>Try more general keywords.</li>" +
                     "<li>Try fewer keywords.</li>" +
                     "</ul>" +
                     "</td></tr>";
    } else {
        restextcomp = '<font face="arial,sans-serif" size="-1" color="white">Results: <b>' + restotal + '</b> in 0.486 sec</font>';
    }
    if (restext) { restext.innerHTML = restextcomp; }
    if (main) { 
        main.innerHTML = "<table width='100%' border='0' cellpadding='2' cellspacing='0'><tbody>" + htmlBuffer + "</tbody></table>"; 
    }
}
