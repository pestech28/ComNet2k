import time
import requests
from bs4 import BeautifulSoup

def main():
    url = "http://68k.news"
    response = requests.get(url)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    links = soup.find_all("a")

    content = [a.get_text(strip=True) for a in links if a.get_text(strip=True)]
    final = []
    i = 13
    for i in range(13, len(content), 6):
        final.append(content[i])
    with open("index.html", "w") as f:
        f.write('''<html>
    <head>
        <title>Headlines.net: Your quick news preview</title>
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">
        <style>
            body {
                width: 100%;
                height: 100%;
                background-color: rgb(0,78,152);
                overflow: auto;
                overflow-x: hidden;
            }
            h1, h2, h3 {
                font-weight: 100;
                color: white;
                font-family: Arial, Helvetica, sans-serif;
            }
            a {
                color: white;
                font-family: Arial, Helvetica, sans-serif;
            }
            .mainui {
                width: 80%;
                height: 4004px;
                background-image: url(mainbg.png);
                display: block;
            }
        </style>
    </head>
    <body>
        <center>
            <div class="mainui">
                <table class="wspace">
                    <tbody>''')
        i = 0
        for i in range(len(final)):
            f.write("<tr><td><h2>" + final[i] + "</h2></td></tr> \n")
        f.write("""</tbody>
                </table>
            </div>
        </center>
    </body>
</html>""")
print("Headline Grabber")
print("Version 1.0")
print("2026-06-08")
try:
    while True:
        print("Downloading news")
        print("Compiling webpage")
        main()
        print("Finished")
        print("Waiting")
        time.sleep(1800)  
except:
    print("Error has occured")
