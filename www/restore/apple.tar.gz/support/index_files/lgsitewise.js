var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
var wtl_imgarray = new Array; 
var wtl_ptr = 0;
function wtl_Tag6(wtl_TagID,wtl_SID,wtl_URL,wtl_Title,CONTENTGROUP)
{

	function wtl_createImage(wtl_src)
	{
		wtl_imgarray[wtl_ptr] = new Image;
		wtl_imgarray[wtl_ptr].src = wtl_src;
		wtl_ptr++; 
	}
	
	function D8( d)
	{
		var fwd=1, seed= new Date('01/01/2000'), key= "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		var s= key.charAt( d.getFullYear()-2000)+key.charAt( d.getMonth()+1)+key.charAt( d.getDate());
		s+= key.charAt( d.getHours())+key.charAt( d.getMinutes())+key.charAt( d.getSeconds());
		while( seed.getDay()!=fwd) seed= new Date(seed.getTime() + 86400000);
		var w= Math.floor( (d.getTime()-(seed.getTime()+86400000)) / 604800000 );
		s+= key.charAt( (w-(w%16))/16 );
		s+= key.charAt( w%16);
		return s;
	}

	function A( B, C)
	{
		W+="&"+B+"="+escape(C);
	}
	
	var t = new Date();
	var W="http"+(document.URL.indexOf('https:')==0?'s':'')+"://statse.webtrendslive.com/S" + wtl_SID + "/button6.asp?tagver=" + wtl_TagVer + "&si=" + wtl_TagID + "&offset=" + wtl_Offset + "&fw=" + wtl_FWD;
	A( "server", typeof(SERVER)== "string" ? SERVER : "");
	A( "order", typeof(ORDER)== "string" ? ORDER : "");
	A( "Group", typeof(CONTENTGROUP)== "string" ? CONTENTGROUP : "");
	A( "invoice", typeof(INVOICE)== "string" ? INVOICE : "");
	A( "cartview", typeof(CARTVIEW)== "string" ? CARTVIEW : "");
	A( "cartadd", typeof(CARTADD)== "string" ? CARTADD : "");
	A( "cartremove", typeof(CARTREMOVE)== "string" ? CARTREMOVE : "");
	A( "checkout", typeof(CHECKOUT)== "string" ? CHECKOUT : "");
	A( "cartbuy", typeof(CARTBUY)== "string" ? CARTBUY : "");
	A( "adcampaign", typeof(ADCAMPAIGN)== "string" ? ADCAMPAIGN : "");
	A( "tz", t.getTimezoneOffset());
	A( "ch", t.getHours());
	A( "cl", D8(t));
	A( "ti", wtl_Title);
	A( "url", wtl_URL);
	A( "rf", window.document.referrer);
	A( "js", "Yes");
	A( "ul", navigator.appName=="Netscape" ? navigator.language : navigator.userLanguage);
	if(typeof(screen)=="object")
	{
	A( "sr", screen.width+"x"+screen.height);
	A( "cd", screen.colorDepth);
	A( "jo", navigator.javaEnabled() ? "Yes" : "No");
	}

	if( W.length>2048 && navigator.userAgent.indexOf('MSIE')>=0)
		W= W.substring( 0, 2043)+"&tu=1";

	wtl_createImage(W);

}


}

/*
     FILE ARCHIVED ON 18:02:04 Jun 05, 2004 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 23:23:36 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 2.544
  captures_list: 0.722
  exclusion.robots: 0.067
  exclusion.robots.policy: 0.051
  esindex: 0.012
  cdx.remote: 5.625
  LoadShardBlock: 197.229 (3)
  PetaboxLoader3.datanode: 159.092 (4)
  PetaboxLoader3.resolve: 93.525 (2)
  load_resource: 89.13
*/