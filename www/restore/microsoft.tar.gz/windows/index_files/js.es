var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
function jsTrim(s) {return s.replace(/(^\s+)|(\s+$)/g, "");}

function trackInfo(objLink)
{
	if (!objLink) return;
	if (!objLink.LinkID || !objLink.href) return;
	
	// For Link Text - take innerText if available, or ALT if image

	var LinkText;
	//if  (objLink.innerText) LinkText = objLink.innerText;	// <A>text</A> link
	//change made 7/19/2002 marmca
	if  (objLink.innerText && jsTrim(objLink.innerText)) LinkText = jsTrim(objLink.innerText);// <A>text</A> link
	else if (objLink.alt) LinkText = objLink.alt;		// <AREA> image map link
	else if (objLink.all(0)) LinkText = objLink.all(0).alt;	// <A><IMG ALT="..."></A> link

	if (!LinkText  || typeof(LinkText)=="undefined") return;
	LinkText = jsTrim(LinkText);
	if (LinkText=="") return;
	
	// override link's HREF and send on its way
	// Sometimes with slow browser reaction and rapid clicks this can get called more than once -
	// ensure there's no repetition.
	if (objLink.href.toString().indexOf("CTRedir") < 0)
		objLink.href = "/isapi/CTRedir.asp?type=CT&source=WWW&sPage=" 
		+ ((objLink.LinkID)?escape(objLink.LinkID):"") + "|" 
		+ ((objLink.LinkArea)?escape(objLink.LinkArea):"") + "|" 
		+ ((objLink.LinkGroup)?escape(objLink.LinkGroup):"") + "|" 
		+ escape(LinkText)
		+ "&tPage=" + objLink.href;
}
function trackSearch(objLink, objText)
{
	if (!objLink) return true;
	if (!objText) return true;
	if (!objLink.LinkID || !objLink.href || !objText.value) return true;

	// override link's HREF and send on its way
	// For Link Text - take innerText if available, or ALT if image
	// Sometimes with slow browser reaction and rapid clicks this can get called more than once -
	// ensure there's no repetition.
	if (objLink.href.toString().indexOf("CTRedir") < 0)
		objLink.href = "/isapi/CTRedir.asp?type=CT&source=WWW&sPage=" 
		+ ((objLink.LinkID)?escape(objLink.LinkID):"") + "|" 
		+ ((objLink.LinkArea)?escape(objLink.LinkArea):"") + "|" 
		+ ((objLink.LinkGroup)?escape(objLink.LinkGroup):"") + "|" 
		+ "Search"
		+ "&tPage=" + objLink.href + escape(objText.value).replace(/(\+)/g,"%2B");
	
	objLink.click(); // click on the link to navigate - allows to have HTTP_REFERRER in CTRedir.asp
	
	return false;
}

}

/*
     FILE ARCHIVED ON 18:43:50 Aug 28, 2004 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 14:56:54 Jun 14, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 6.323
  load_resource: 119.461
  PetaboxLoader3.resolve: 100.962
  PetaboxLoader3.datanode: 17.53
*/