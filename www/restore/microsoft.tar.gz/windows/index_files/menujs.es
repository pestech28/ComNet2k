var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");


function mnpMenuDir()
{
	return "LTR";
}

function mnpMenuCT()
{
	
	return true;
}

function m0665c1299e0991bfc174c8c9db358ca1()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Windows XP Home', '/windowsxp/default.mspx', '', '', '_S1_Node1_S1_Node1');
	this.items[n++] = new mnpPage('Windows XP Professional', '/windowsxp/pro/default.mspx', '', '', '_S1_Node1_S1_Node2');
	this.items[n++] = new mnpPage('Windows XP Home Edition', '/windowsxp/home/default.mspx', '', '', '_S1_Node1_S1_Node3');
	this.items[n++] = new mnpPage('Windows XP Media Center Edition', '/windowsxp/mediacenter/default.mspx', '', '', '_S1_Node1_S1_Node4');
	this.items[n++] = new mnpPage('Windows XP Tablet PC Edition', '/windowsxp/tabletpc/default.mspx', '', '', '_S1_Node1_S1_Node5');
}

function mddfe79012baa4c22878be818dd944c6a()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Windows Server System Home', '/windowsserversystem/default.mspx', '', '', '_S1_Node3_S1_Node1');
	this.items[n++] = new mnpPage('Windows Server 2003', '/windowsserver2003/default.mspx', '', '', '_S1_Node3_S1_Node2');
	this.items[n++] = new mnpPage('Windows Small Business Server 2003', '/windowsserver2003/sbs/default.mspx', '', '', '_S1_Node3_S1_Node3');
}

function m0ac43c643136f39013a782932a47c87b()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Windows Embedded Home', '/windows/embedded/default.mspx', '', '', '_S1_Node4_S1_Node1');
	this.items[n++] = new mnpPage('Windows CE .NET', 'https://web.archive.org/web/20040829050259/http://msdn.microsoft.com/embedded/ce.net/default.aspx', '', '', '_S1_Node4_S1_Node2');
	this.items[n++] = new mnpPage('Windows XP Embedded', 'https://web.archive.org/web/20040829050259/http://msdn.microsoft.com/embedded/xp/default.aspx', '', '', '_S1_Node4_S1_Node3');
}

function m27d756783373eb36ea88fa7e15c49a13()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Other Versions: Overview', '/windows/otherversions/default.mspx', '', '', '_S1_Node6_S1_Node1');
	this.items[n++] = new mnpPage('Windows 2000', '/windows2000/default.asp', '', '', '_S1_Node6_S1_Node2');
	this.items[n++] = new mnpPage('Windows Me', '/windowsme/default.asp', '', '', '_S1_Node6_S1_Node3');
	this.items[n++] = new mnpPage('Windows 98', '/windows98/default.asp', '', '', '_S1_Node6_S1_Node4');
	this.items[n++] = new mnpPage('Windows 95', '/windows95/default.asp', '', '', '_S1_Node6_S1_Node5');
	this.items[n++] = new mnpPage('Windows NT Workstation', '/ntworkstation/default.asp', '', '', '_S1_Node6_S1_Node6');
	this.items[n++] = new mnpPage('Windows NT Server', '/ntserver/default.asp', '', '', '_S1_Node6_S1_Node7');
}

function m67214631a36b245b70e25de65e0774f7()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Trial Software: Overview', '/windows/trial/default.mspx', '', '', '_S3_Node2_S1_Node1');
	this.items[n++] = new mnpPage('Windows Server 2003', '/windowsserver2003/evaluation/trial/', '', '', '_S3_Node2_S1_Node2');
	this.items[n++] = new mnpPage('Microsoft Operations Manager', '/mom/evaluation/ordercd/default.asp', '', '', '_S3_Node2_S1_Node3');
	this.items[n++] = new mnpPage('Systems Management Server', '/SMServer/evaluation/trial/default.asp', '', '', '_S3_Node2_S1_Node4');
	this.items[n++] = new mnpPage('Windows Embedded Evaluation Kit', 'https://web.archive.org/web/20040829050259/http://msdn.microsoft.com/embedded/evaluate/evalkit/default.aspx', '', '', '_S3_Node2_S1_Node5');
}

function m8fcb59081a0928a55a6324abd304c9cf()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Communities: Overview', '/windows/communities/default.mspx', '', '', '_S3_Node3_S1_Node1');
	this.items[n++] = new mnpPage('Windows XP Expert Zone Community', '/windowsxp/expertzone/default.mspx', '', '', '_S3_Node3_S1_Node2');
	this.items[n++] = new mnpPage('Windows Server Community', '/windows2000/community/default.asp', '', '', '_S3_Node3_S1_Node3');
	this.items[n++] = new mnpPage('Windows Storage Community', '/windowsserversystem/storage/community/default.mspx', '', '', '_S3_Node3_S1_Node4');
	this.items[n++] = new mnpPage('Windows Embedded Community', 'https://web.archive.org/web/20040829050259/http://msdn.microsoft.com/embedded/community/default.aspx', '', '', '_S3_Node3_S1_Node5');
}


}

/*
     FILE ARCHIVED ON 05:02:59 Aug 29, 2004 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 14:56:54 Jun 14, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.373
  load_resource: 63.359
  PetaboxLoader3.resolve: 47.463
  PetaboxLoader3.datanode: 14.215
*/