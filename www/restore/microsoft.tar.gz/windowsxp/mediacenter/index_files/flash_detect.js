var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");

function isDefined(property) {
  return (typeof property != 'undefined');
}

var flashVersion = 0;
function getFlashVersion() {
	var latestFlashVersion = 8;
   var agent = navigator.userAgent.toLowerCase(); 
	
   // NS3 needs flashVersion to be a local variable
   if (agent.indexOf("mozilla/3") != -1 && agent.indexOf("msie") == -1) {
      flashVersion = 0;
   }
   
	// NS3+, Opera3+, IE5+ Mac (support plugin array):  check for Flash plugin in plugin array
	if (navigator.plugins != null && navigator.plugins.length > 0) {
		var flashPlugin = navigator.plugins['Shockwave Flash'];
		if (typeof flashPlugin == 'object') { 
			for (var i = latestFlashVersion; i >= 3; i--) {
            if (flashPlugin.description.indexOf(i + '.') != -1) {
               flashVersion = i;
               break;
            }
         }
		}
	}

	// IE4+ Win32:  attempt to create an ActiveX object using VBScript
	else if (agent.indexOf("msie") != -1 && parseInt(navigator.appVersion) >= 4 && agent.indexOf("win")!=-1 && agent.indexOf("16bit")==-1) {
	   var doc = '<scr' + 'ipt language="VBScript"\> \n';
      doc += 'On Error Resume Next \n';
      doc += 'Dim obFlash \n';
      doc += 'For i = ' + latestFlashVersion + ' To 3 Step -1 \n';
      doc += '   Set obFlash = CreateObject("ShockwaveFlash.ShockwaveFlash." & i) \n';
      doc += '   If IsObject(obFlash) Then \n';
      doc += '      flashVersion = i \n';
      doc += '      Exit For \n';
      doc += '   End If \n';
      doc += 'Next \n';
      doc += '</scr' + 'ipt\> \n';
      document.write(doc);
   }
		
	// WebTV 2.5 supports flash 3
	else if (agent.indexOf("webtv/2.5") != -1) flashVersion = 3;

	// older WebTV supports flash 2
	else if (agent.indexOf("webtv") != -1) flashVersion = 2;

	// Can't detect in all other cases
	else {
		flashVersion = flashVersion_DONTKNOW;
	}

	return flashVersion;
}

flashVersion_DONTKNOW = -1;
}

/*
     FILE ARCHIVED ON 19:47:51 Aug 28, 2004 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:33:32 Jun 14, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.559
  load_resource: 112.462
  PetaboxLoader3.resolve: 84.612
  PetaboxLoader3.datanode: 19.15
*/