var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");


function mnpMenuDir()
{
	return "LTR";
}

function mnpMenuCT()
{
	
	return true;
}

function m411cbd32e4454d2bbab975a96b7e969e()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Product Information: Overview', '/windowsxp/pro/evaluation/default.mspx', '', '', '_S1_Node1_S1_Node1');
	this.items[n++] = new mnpPage('Product Overview', '/windowsxp/pro/evaluation/overviews/default.mspx', '', '', '_S1_Node1_S1_Node2');
	this.items[n++] = new mnpPage('Features', '/windowsxp/pro/evaluation/features.mspx', '', '', '_S1_Node1_S1_Node3');
	this.items[n++] = new mnpPage('Tours and Demos', '/windowsxp/pro/evaluation/tours/default.mspx', '', '', '_S1_Node1_S1_Node4');
	this.items[n++] = new mnpPage('System Requirements', '/windowsxp/pro/evaluation/sysreqs.mspx', '', '', '_S1_Node1_S1_Node5');
	this.items[n++] = new mnpPage('Why Upgrade?', '/windowsxp/pro/evaluation/whyupgrade/default.mspx', '', '', '_S1_Node1_S1_Node6');
}

function m90f0c3765598a8f6d936ceb105f60def()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Using Windows XP: Overview', '/windowsxp/using/default.mspx', '', '', '_S2_Node1_S1_Node1');
	this.items[n++] = new mnpPage('Digital Photography', '/windowsxp/using/digitalphotography/default.mspx', '', '', '_S2_Node1_S1_Node2');
	this.items[n++] = new mnpPage('Games for Windows', '/windowsxp/using/games/default.mspx', '', '', '_S2_Node1_S1_Node3');
	this.items[n++] = new mnpPage('Movies', '/windowsxp/using/moviemaker/default.mspx', '', '', '_S2_Node1_S1_Node4');
	this.items[n++] = new mnpPage('Music and Video', '/windowsxp/using/windowsmediaplayer/default.mspx', '', '', '_S2_Node1_S1_Node5');
	this.items[n++] = new mnpPage('Instant Messaging', '/windowsxp/using/windowsmessenger/default.mspx', '', '', '_S2_Node1_S1_Node6');
	this.items[n++] = new mnpPage('Security and Privacy', '/windowsxp/using/security/default.mspx', '', '', '_S2_Node1_S1_Node7');
	this.items[n++] = new mnpPage('Computer Setup and Maintenance', '/windowsxp/using/setup/default.mspx', '', '', '_S2_Node1_S1_Node8');
	this.items[n++] = new mnpPage('Home and Small Business Networking', '/windowsxp/using/networking/default.mspx', '', '', '_S2_Node1_S1_Node9');
	this.items[n++] = new mnpPage('Working Remotely', '/windowsxp/using/mobility/default.mspx', '', '', '_S2_Node1_S1_Node10');
	this.items[n++] = new mnpPage('Web Browsing and E-mail', '/windowsxp/using/web/default.mspx', '', '', '_S2_Node1_S1_Node11');
	this.items[n++] = new mnpPage('Pen and Ink', '/windowsxp/using/tabletpc/default.mspx', '', '', '_S2_Node1_S1_Node12');
	this.items[n++] = new mnpPage('TV and Multimedia', '/windowsxp/using/mce/default.mspx', '', '', '_S2_Node1_S1_Node13');
}

function m0ab75ea5c65258a4d0f711a14581bde7()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Downloads: Overview', '/windowsxp/downloads/default.mspx', '', '', '_S2_Node2_S1_Node1');
	this.items[n++] = new mnpPage('Software Updates', '/windowsxp/downloads/updates/default.mspx', '', '', '_S2_Node2_S1_Node2');
	this.items[n++] = new mnpPage('Tools and Utilities', '/windowsxp/downloads/tools/default.mspx', '', '', '_S2_Node2_S1_Node3');
	this.items[n++] = new mnpPage('Power Toys and Add-ins', '/windowsxp/downloads/powertoys/default.mspx', '', '', '_S2_Node2_S1_Node4');
	this.items[n++] = new mnpPage('Desktop Enhancements', '/windowsxp/downloads/desktop/default.mspx', '', '', '_S2_Node2_S1_Node5');
}

function m79bcb962cfe9a15079154b3f186bd916()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Expert Zone Community', '/windowsxp/expertzone/default.mspx', '', '', '_S2_Node4_S1_Node1');
	this.items[n++] = new mnpPage('Columns', '/windowsxp/expertzone/columns/archive.mspx', '', '', '_S2_Node4_S1_Node2');
	this.items[n++] = new mnpPage('Newsgroups', '/windowsxp/expertzone/newsgroups.mspx', '', '', '_S2_Node4_S1_Node3');
	this.items[n++] = new mnpPage('Chats', '/windowsxp/expertzone/chats/default.mspx', '', '', '_S2_Node4_S1_Node4');
	this.items[n++] = new mnpPage('Related Communities', '/windowsxp/expertzone/relatedsites.mspx', '', '', '_S2_Node4_S1_Node5');
	this.items[n++] = new mnpPage('Other Microsoft Communities', '/windowsxp/expertzone/relatedcomm.mspx', '', '', '_S2_Node4_S1_Node6');
	this.items[n++] = new mnpPage('User Groups', '/windowsxp/expertzone/usergroups/default.mspx', '', '', '_S2_Node4_S1_Node7');
	this.items[n++] = new mnpPage('Meet the Experts', '/windowsxp/expertzone/meetexperts/default.mspx', '', '', '_S2_Node4_S1_Node8');
}

function m830408569122205f4691f65de881aef3()
{
	this.items = new Array();
	var n = 0;
	this.items[n++] = new mnpPage('Windows Family', '/windows/default.asp', '', '', '_S3_Node1_S1_Node1');
	this.items[n++] = new mnpPage('Windows XP', '/windowsxp/default.asp', '', '', '_S3_Node1_S1_Node2');
	this.items[n++] = new mnpPage('Plus!', '/windows/plus/PlusHome.asp', '', '', '_S3_Node1_S1_Node3');
	this.items[n++] = new mnpPage('Windows Server System Home', '/windowsserversystem/default.mspx', '', '', '_S3_Node1_S1_Node4');
	this.items[n++] = new mnpPage('Windows Server 2003', '/windowsserver2003/default.mspx', '', '', '_S3_Node1_S1_Node5');
	this.items[n++] = new mnpPage('Windows Small Business Server 2003', '/windowsserver2003/sbs/default.mspx', '', '', '_S3_Node1_S1_Node6');
	this.items[n++] = new mnpPage('Windows 2000', '/windows2000/', '', '', '_S3_Node1_S1_Node7');
	this.items[n++] = new mnpPage('Windows NT Workstation 4.0', '/ntworkstation/default.asp', '', '', '_S3_Node1_S1_Node8');
	this.items[n++] = new mnpPage('Windows NT Server 4.0', '/windows/ntserver/default.asp', '', '', '_S3_Node1_S1_Node9');
	this.items[n++] = new mnpPage('Windows Me', '/windowsme/default.asp', '', '', '_S3_Node1_S1_Node10');
	this.items[n++] = new mnpPage('Windows 98', '/windows98/default.asp', '', '', '_S3_Node1_S1_Node11');
	this.items[n++] = new mnpPage('Windows 95', '/windows95/default.asp', '', '', '_S3_Node1_S1_Node12');
	this.items[n++] = new mnpPage('Windows Embedded', 'https://web.archive.org/web/20040829011615/http://msdn.microsoft.com/embedded/', '', '', '_S3_Node1_S1_Node13');
	this.items[n++] = new mnpPage('Internet Explorer', '/windows/ie/default.asp', '', '', '_S3_Node1_S1_Node14');
	this.items[n++] = new mnpPage('Windows Media Player', '/windows/windowsmedia/default.asp', '', '', '_S3_Node1_S1_Node15');
	this.items[n++] = new mnpPage('DirectX', '/windows/directx/default.asp', '', '', '_S3_Node1_S1_Node16');
	this.items[n++] = new mnpPage('Smart Display', '/windows/smartdisplay/default.mspx', '', '', '_S3_Node1_S1_Node17');
}


}

/*
     FILE ARCHIVED ON 01:16:15 Aug 29, 2004 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:02:28 Jun 14, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 2.633
  load_resource: 122.365
  PetaboxLoader3.resolve: 97.816
  PetaboxLoader3.datanode: 8.75
*/