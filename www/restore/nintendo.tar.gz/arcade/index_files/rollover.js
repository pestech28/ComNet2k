var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
// Rollover  v1.0
// http://www.dithered.com/javascript/rollover/index.html
// code by Chris Nott (chris@NOSPAMdithered.com - remove NOSPAM)

var rolloverImageOff = new Array();
var rolloverImageOn = new Array();
var rolloverCurrent = '';
var rolloverInitialized = false;
var rolloverNeeded = true;

// Preload rollover images
function rolloverInit() {
	if(!rolloverInitialized){
	   if (document.images) {
	
	      // for each rollover, preload both states and put filename in an associative array
	      for (var i = 0; i < rolloverImageOnFiles.length; i++) {
	         rolloverCurrentName = rolloverImageTagNames[i];
	
	         rolloverImageOff[rolloverCurrentName] = new Image();
	         rolloverImageOn[rolloverCurrentName] = new Image();
	         rolloverImageOff[rolloverCurrentName].src = rolloverImageDirectory + rolloverImageOffFiles[i];
	         rolloverImageOn[rolloverCurrentName].src = rolloverImageDirectory + rolloverImageOnFiles[i];
	      }
	      rolloverInitialized = true;
	   }
	}//end if rolloverInitialized
}


function rolloverOn(img, layer) {
   if (document.images && rolloverImageOn[img]) {
      
      // 1. Force the correct local folder path
      const basePath = 'index_files/';
      
      // 2. Get the full string (e.g., "http://img/text/topnav_ds25_off.png")
      const originalSrc = rolloverImageOn[img].src;
      
      // 3. Extract ONLY the clean filename: "topnav_ds25_off.png"
      const filename = originalSrc.substring(originalSrc.lastIndexOf('/') + 1);
      
      // 4. Combine them to create: "index_file/topnav_ds25_off.png"
      const newSrc = basePath + filename;

      // Assign the corrected path to the image
      if (document.images[img]) {
         document.images[img].src = newSrc;
      }
      else if (layer != null && document.layers) {
         if (typeof(layer) == 'object') {
            layer.document.images[img].src = newSrc;
         } else if (typeof(layer) == 'string') {
            document.layers[layer].document.images[img].src = newSrc;
         }
      }
   }
}

// Off state activation
function rolloverOff(img, layer) {
   if (document.images && rolloverImageOff[img]) {

      // 1. Force the correct local folder path
      const basePath = 'index_files/';
      
      // 2. Get the full string from the Off-state array
      const originalSrc = rolloverImageOff[img].src;
      
      // 3. Extract ONLY the clean filename
      const filename = originalSrc.substring(originalSrc.lastIndexOf('/') + 1);
      
      // 4. Combine them into the correct path
      const newSrc = basePath + filename;

      // Assign the corrected path to the image
      if (document.images[img]) {
         document.images[img].src = newSrc;
      }
      else if (layer != null && document.layers) {
         if (typeof(layer) == 'object') {
            layer.document.images[img].src = newSrc;
         } else if (typeof(layer) == 'string') {
            document.layers[layer].document.images[img].src = newSrc;
         }
      }
   }
}


function rolloverInputOn(btn, img) {
   btn.src = rolloverImageOn[img].src;
}

function rolloverInputOff(btn, img) {
   btn.src = rolloverImageOff[img].src;
}

// Rollover with state function (not used in standard rollovers; included for flexability)
function rolloverSetCurrent(img) {
   if (rolloverCurrent) rolloverOff(rolloverCurrent);
   rolloverCurrent = img;
   rolloverOn(rolloverCurrent);
}

// function for page specific rollovers
function preloadRollover(onFile, offFile, tagName) {
   var index = rolloverImageOffFiles.length;
   rolloverImageOnFiles[index] = onFile;
   rolloverImageOffFiles[index] = offFile;
   rolloverImageTagNames[index] = tagName;
}



}

/*
     FILE ARCHIVED ON 21:32:28 Dec 05, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 00:36:52 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.268
  captures_list: 0.354
  exclusion.robots: 0.032
  exclusion.robots.policy: 0.025
  esindex: 0.006
  cdx.remote: 5.997
  LoadShardBlock: 42.853 (3)
  PetaboxLoader3.datanode: 63.482 (4)
  load_resource: 129.302
  PetaboxLoader3.resolve: 96.393
*/