var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
/*********************************
   nav.js for Nintendo.com
   js code for Nintendo.com redesign prototype
   code by Chad Lindstrom (chad.lindstrom(AT)blastradius.com)
*********************************/
var currentflyout = null;

function toggleMenuLayer(layer,mark,parent,left,top) {
   layer = getElm(layer);
   if(!layer)
      return;
   if(isNaN(left) == true)
      left = 0;
   if(isNaN(top) == true)
      top = 0;

   if(currentflyout && currentflyout != layer && currentflyout.style.display == "block")
   {
      currentflyout.style.display = "none"
      var m = currentflyout.mark;
      m.className = m.className.substring(0,m.className.indexOf(" hover"));
   }
   mark = check(mark);
   currentflyout = layer;
   layer.mark = mark;
   //layer.style.top  = (getOffsetProperty(mark, "Top",parent) + mark.offsetHeight + top) +"px";
   layer.style.top  = (getOffsetProperty(mark, "Top",parent)  + top) - 9  +"px";
   layer.style.left = (getOffsetProperty(mark, "Left",parent) + left) + 1 +"px";

   if(layer.style.display == "block")
   {
      layer.style.display = "none";
      mark.className = mark.className.substring(0,mark.className.indexOf(" hover"));
      //safariFlashFix("show");
   }else{
      layer.style.display = "block";
      mark.className = mark.className +" hover";
      if(getElm(layer.id+"BG"))
      {
         var bg = getElm(layer.id+"BG");
         bg.style.height = layer.offsetHeight +"px";
         if(isMac && !isSafari)
            setOpacity(bg,100);
      }
      //safariFlashFix("hide");
   }
}

function showMenuLayer(layer,mark,parent,left,top) {
   if(currentflyout && currentflyout.style.display == "block") {
      currentflyout.style.display = "none";
      var m = currentflyout.mark;
      m.className = m.className.substring(0,m.className.indexOf(" hover"));
   }
   keepUp(getElm(layer));
   toggleMenuLayer(layer,mark,parent,left,top);
}

function delayHide(elm){
      if(typeof elm != "object")
         elm = getElm(elm);
      elm.keepMeUp = false;
      setTimeout('hideMenuLayer()',100);
}

function keepUp(elm){
   if(!elm)
      return;
      elm.keepMeUp = true;
}

function hideMenuLayer(){
      if(!currentflyout)
         return;
      if(!currentflyout.keepMeUp)
      {
         currentflyout.style.display = "none";
         var mark = currentflyout.mark;
         mark.className = mark.className.substring(0,mark.className.indexOf(" hover"));
         currentflyout = null;
         //safariFlashFix("show");
      }
}
}

/*
     FILE ARCHIVED ON 16:05:40 Dec 16, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:59:13 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.638
  captures_list: 0.608
  exclusion.robots: 0.05
  exclusion.robots.policy: 0.039
  esindex: 0.01
  cdx.remote: 6.747
  LoadShardBlock: 317.042 (3)
  PetaboxLoader3.datanode: 91.788 (4)
  PetaboxLoader3.resolve: 192.056 (2)
  load_resource: 77.554
*/