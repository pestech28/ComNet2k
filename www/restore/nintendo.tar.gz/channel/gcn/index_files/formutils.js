var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
/*********************************
   formutils.js for Nintendo.com
   js code for Nintendo.com forms
   code by Chad Lindstrom (chad.lindstrom(AT)blastradius.com)
*********************************/
function checkChecked(radios,errorMsg) {
   var isChecked = false;
   for(i=0; i<radios.length; i++) {
      if(radios[i].checked == true){
         isChecked = true;
         break;
      }
   }
   if(isChecked == false){
      alert(errorMsg);
   }
   return isChecked;
}
}

/*
     FILE ARCHIVED ON 21:30:33 Dec 05, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:06:39 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.663
  captures_list: 0.312
  exclusion.robots: 0.029
  exclusion.robots.policy: 0.024
  esindex: 0.006
  cdx.remote: 38.657
  LoadShardBlock: 107.801 (3)
  PetaboxLoader3.datanode: 108.383 (4)
  PetaboxLoader3.resolve: 121.062 (2)
  load_resource: 160.252
*/