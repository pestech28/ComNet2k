var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
/*********************************
   globalutils.js for Nintendo.com
   js code for Nintendo.com site
   code by Chad Lindstrom (chad.lindstrom(AT)blastradius.com)
*********************************/


/* gives window prompt if URL is not in the *.nintendo.com domain
   returns false if in nintendo domain, not opening a new window
   */
function LaunchURL( url ){

   if( url.match(/http:/) ) {
      if( ! url.match(/http:\/\/(.+\.|)nintendo\.com/) ){
         // /externallink?link=http%3A%2F%2Fwww.4Kids.tvtest
         //encode URL???
         openCenteredWindow("/externallink?link="+url, 'window2', 350, 320, true, true, true, 'opener'); return false;
         return false;
      }
   }
   return true;
}
}

/*
     FILE ARCHIVED ON 20:52:38 Dec 05, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:44:47 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 1.807
  captures_list: 0.616
  exclusion.robots: 0.077
  exclusion.robots.policy: 0.051
  esindex: 0.008
  cdx.remote: 56.883
  LoadShardBlock: 345.393 (3)
  PetaboxLoader3.datanode: 335.874 (4)
  PetaboxLoader3.resolve: 313.572 (2)
  load_resource: 309.998
*/