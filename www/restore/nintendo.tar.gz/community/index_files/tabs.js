var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
/*******************
 tabs.js
// for use with NOA tab sets
// code by Byron Tredwell (byron@NOSPAM.blastradius.com)
********************************************************/

function tabSet(cT, lS, rS)
{
   this.ct = null;
   this.ls = null;
   this.rs = null;
   this.setActive(cT, lS, rS)
}

tabSet.prototype.setActive = function(cT, lS, rS)
{
   if(this.ct != null)
   {
      document.getElementById("tab"+this.ct).className = "tabOff";
      document.getElementById("link"+this.ct).className = "linkWhite";
      if(this.ls != null)
         this.ls.src = "img/tab_splitter_none.gif";
      if(this.rs != null)
         this.rs.src = "img/tab_splitter_none.gif";
   }
   
      document.getElementById("tab"+cT).className = "tabOn";
      document.getElementById("link"+cT).className = "linkYellow"; 
      
      this.ct = cT;
      if(lS != null && lS != '')
      {
         document.getElementById(lS).src = "img/tab_splitter_on.gif";
         this.ls = document.getElementById(lS);
      }else{
         this.ls = null;
      }
      if(rS != null && rS != '')
      {
         document.getElementById(rS).src = "img/tab_splitter_off.gif";
         this.rs = document.getElementById(rS);
      }else{
         this.rs = null;  
      }
      
}

function sortSet(cS)
{
   this.cs = null;
   this.setActive(cS)
}

sortSet.prototype.setActive = function(cS)
{
   if(this.cs != null)
   {
      var linkT = document.getElementById("link"+this.cs)
      linkT.className = "linkWhite";
      document.getElementById("sort"+this.cs).className = "sortUnSelect";
   }
      var linkT = document.getElementById("link"+cS)
      linkT.className = "linkYellow";
      document.getElementById("sort"+cS).className = "sortSelect";
      
      this.cs = cS;
}


var currentTopGamesTabName = 'Top10';
function topGamesSetActive(tabName) {
   document.getElementById('tab' + currentTopGamesTabName).className = 'topgamesTab tabOff';
   document.getElementById('tab' + tabName).className = 'topgamesTab tabOn';
   currentTopGamesTabName = tabName;
}
}

/*
     FILE ARCHIVED ON 01:40:51 Dec 06, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:47:32 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 1.375
  captures_list: 1.126
  exclusion.robots: 0.108
  exclusion.robots.policy: 0.081
  esindex: 0.022
  cdx.remote: 6.416
  LoadShardBlock: 79.807 (3)
  PetaboxLoader3.datanode: 122.607 (4)
  load_resource: 259.669
  PetaboxLoader3.resolve: 185.14
*/