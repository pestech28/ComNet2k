var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
// Rollover  v1.0
// http://www.dithered.com/javascript/rollover/index.html
// code by Chris Nott (chris@NOSPAMdithered.com - remove NOSPAM)

var rolloverImageOff = new Array();
var rolloverImageOn = new Array();
var rolloverCurrent = '';
var rolloverInitialized = false;
var rolloverNeeded = true;

// Preload rollover images
function rolloverInit() {
	if(!rolloverInitialized){
	   if (document.images) {
	
	      // for each rollover, preload both states and put filename in an associative array
	      for (var i = 0; i < rolloverImageOnFiles.length; i++) {
	         rolloverCurrentName = rolloverImageTagNames[i];
	
	         rolloverImageOff[rolloverCurrentName] = new Image();
	         rolloverImageOn[rolloverCurrentName] = new Image();
	         rolloverImageOff[rolloverCurrentName].src = rolloverImageDirectory + rolloverImageOffFiles[i];
	         rolloverImageOn[rolloverCurrentName].src = rolloverImageDirectory + rolloverImageOnFiles[i];
	      }
	      rolloverInitialized = true;
	   }
	}//end if rolloverInitialized
}


// On state activation
function rolloverOn(img, layer) {
   if (document.images && rolloverImageOn[img]) {
      // rollovers in layers in NS4 require a different image reference
      if (layer != null && document.layers) {
         if (typeof(layer) == 'object') layer.document.images[img].src = rolloverImageOn[img].src;
         else if (typeof(layer) == 'string') eval('document.layers["' + layer + '"].document.images[img].src = rolloverImageOn[img].src');
      }

      // non-layer rollovers in NS4 and all rollovers in other browsers
      else if (document.images[img]){
         document.images[img].src = rolloverImageOn[img].src;
      }
   }
}


// Off state activation
function rolloverOff(img, layer) {
   if (document.images && rolloverImageOff[img]) {

      // rollovers in layers in NS4 require a different image reference
      if (layer != null && document.layers) {
         if (typeof(layer) == 'object') layer.document.images[img].src = rolloverImageOff[img].src;
         else if (typeof(layer) == 'string') eval('document.layers["' + layer + '"].document.images[img].src = rolloverImageOff[img].src');
      }

      // non-layer rollovers in NS4 and all rollovers in other browsers
      else if (document.images[img]) document.images[img].src = rolloverImageOff[img].src;
   }
}


function rolloverInputOn(btn, img) {
   btn.src = rolloverImageOn[img].src;
}

function rolloverInputOff(btn, img) {
   btn.src = rolloverImageOff[img].src;
}

// Rollover with state function (not used in standard rollovers; included for flexability)
function rolloverSetCurrent(img) {
   if (rolloverCurrent) rolloverOff(rolloverCurrent);
   rolloverCurrent = img;
   rolloverOn(rolloverCurrent);
}

// function for page specific rollovers
function preloadRollover(onFile, offFile, tagName) {
   var index = rolloverImageOffFiles.length;
   rolloverImageOnFiles[index] = onFile;
   rolloverImageOffFiles[index] = offFile;
   rolloverImageTagNames[index] = tagName;
}



}

/*
     FILE ARCHIVED ON 00:35:38 Feb 09, 2007 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:21:25 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.589
  captures_list: 0.576
  exclusion.robots: 0.055
  exclusion.robots.policy: 0.043
  esindex: 0.012
  cdx.remote: 23.871
  LoadShardBlock: 103.488 (3)
  PetaboxLoader3.datanode: 123.024 (4)
  load_resource: 131.611
  PetaboxLoader3.resolve: 76.222
*/