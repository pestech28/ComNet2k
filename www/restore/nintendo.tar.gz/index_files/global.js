var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
// global.js
// global javascript functions

// basic buggy browsers
var ua = navigator.userAgent.toLowerCase();
var isIE = (ua.indexOf('msie') != -1 && !this.isOpera && (ua.indexOf('webtv') == -1) );
var isSafari = (ua.indexOf('safari') !=-1);
var isMac = (ua.indexOf('mac') !=-1);

// Write a cookie value
function setCookie(name, value, expires, path, domain, secure) {
   var curCookie = name + '=' + escape(value) + ((expires) ? '; expires=' + expires.toGMTString() : '') + ((path) ? '; path=' + path : '') + ((domain) ? '; domain=' + domain : '') + ((secure) ? '; secure' : '');
   document.cookie = curCookie;
}


// Retrieve a named cookie value
function getCookie(name) {
   var dc = document.cookie;

   // find beginning of cookie value in document.cookie
   var prefix = name + "=";
   var begin = dc.indexOf("; " + prefix);
   if (begin == -1) {
      begin = dc.indexOf(prefix);
      if (begin != 0) return null;
   }
   else begin += 2;

   // find end of cookie value
   var end = document.cookie.indexOf(";", begin);
   if (end == -1) end = dc.length;

   // return cookie value
   return unescape(dc.substring(begin + prefix.length, end));
}


// Delete a named cookie value
function deleteCookie(name, path, domain) {
   var value = getCookie(name);
   if (value != null) document.cookie = name + '=' + ((path) ? '; path=' + path : '') + ((domain) ? '; domain=' + domain : '') + '; expires=Thu, 01-Jan-70 00:00:01 GMT';
   return value;
}

// checks to make sure browser is up to date. if it isn't, re-directs to a browser upgrade page
function getBrowserVersion() {

   var ua = navigator.userAgent.toLowerCase();
   // browser version
   var versionMinor = 0;
   var isOk = false;

   // browser name
   var isGecko     = (ua.indexOf('gecko') != -1);
   var isMozilla   = (this.isGecko && ua.indexOf("gecko/") + 14 == ua.length);
   var isNS        = ( (this.isGecko) ? (ua.indexOf('netscape') != -1) : ( (ua.indexOf('mozilla') != -1) && (ua.indexOf('spoofer') == -1) && (ua.indexOf('compatible') == -1) && (ua.indexOf('opera') == -1) && (ua.indexOf('webtv') == -1) && (ua.indexOf('hotjava') == -1) ) );
   var isIE        = ( (ua.indexOf("msie") != -1) && (ua.indexOf("opera") == -1) && (ua.indexOf("webtv") == -1) );
   var isFire	    = ( (ua.indexOf("firebird") != -1) || (ua.indexOf("firefox") != -1) );
   var isOpera	    = (ua.indexOf("opera") != -1);
   var isNitro	    = (ua.indexOf("nitro") != -1);

   if (isOpera) {
      versionMinor =  parseFloat (ua.substring( ua.lastIndexOf('/') + 1 ) );
	  if (versionMinor == 4) {
		versionMinor =  parseFloat (ua.substring( ua.lastIndexOf("opera") + 6 ) );
	  }
      if(versionMinor >= 8.5) isOk = true;
      document.write('<style type="text/css">body > div[align=center] {text-align: left; }</style>');
   }   
   
   if (isFire) {
      isOk = true;
   }
   if (isNitro) {
      isOk = true;
	  document.write('<style type="text/css">#navContainer #login {left:-150px; }</style>');
   }

   // version number
   if (isNS && isGecko) {
      versionMinor = parseFloat( ua.substring( ua.lastIndexOf('/') + 1 ) );
      if(versionMinor >= 6.2) isOk = true;
   }
   else if (isIE) {
      versionMinor = parseFloat( ua.substring( ua.indexOf('msie ') + 5 ) );
      if(versionMinor >= 6.0) isOk = true;
   }
   else if (isMozilla) {
      versionMinor = parseFloat( ua.substring( ua.indexOf('rv:') + 3 ) );
      if(versionMinor >= 0.98) isOk = true;
   }
   
   if( !isOk ){   
   	var crawlers = new Array("googlebot","crawler","msnbot","seeker","slurp","spider","jeeves","infoseek","libwww-perl","altavista");
   	for (var i = 0; i<crawlers.length; i++){
   		if( ua.indexOf( crawlers[i] ) != -1 ){
   			isOk = true;
   			break;
   		}
   	}
   }
   
   return isOk;
}

if( getBrowserVersion() == false && getCookie("ignorecheck") != "yes") {
   top.location.href="/old_browser.vm";
}


// checks to make sure flash 6 is installed
var flashVersion = 0;
function getFlashVersion() {
   var agent = navigator.userAgent.toLowerCase();

   // NS3 needs flashVersion to be a local variable
   if (agent.indexOf("mozilla/3") != -1 && agent.indexOf("msie") == -1) {
      flashVersion = 0;
   }

   // NS3+, Opera3+, IE5+ Mac (support plugin array):  check for Flash plugin in plugin array
   if (navigator.plugins != null && navigator.plugins.length > 0) {
      var flashPlugin = navigator.plugins['Shockwave Flash'];
      if (typeof flashPlugin == 'object') {
         flashVersion = flashPlugin.description.match(/\d+/)[0];
      }
   }

   // IE4+ Win32:  attempt to create an ActiveX object using VBScript
   else if (agent.indexOf("msie") != -1 && parseInt(navigator.appVersion) >= 4 && agent.indexOf("win")!=-1 && agent.indexOf("16bit")==-1) {
      try{
         var axo=new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
         for(var i=3;axo!=null;i++){
            axo=new ActiveXObject("ShockwaveFlash.ShockwaveFlash."+i);
            flashVersion = i;
         }
      }
      catch(e){}
  }

   // WebTV 2.5 supports flash 3
   else if (agent.indexOf("webtv/2.5") != -1) flashVersion = 3;

   // older WebTV supports flash 2
   else if (agent.indexOf("webtv") != -1) flashVersion = 2;

   // Can't detect in all other cases
   else {
      flashVersion = flashVersion_DONTKNOW;
   }

   return flashVersion;
}

flashVersion_DONTKNOW = -1;

var requiredVersion = 6;
var flashVersion = getFlashVersion();
	
	if (flashVersion < requiredVersion && getCookie("ignoreflash") != "yes") {
		if (! ( (ua.indexOf('mozilla') != -1) && (ua.indexOf('opera') != -1) ) ){
			top.location = '/no_flash.vm';
		} 
	}


// Window opener functions  v1.0.6
// http://www.dithered.com/javascript/window/index.html
// code by Chris Nott (chris@NOSPAMdithered.com - remove NOSPAM)

/*******************************************************************************
   Popup Window openers
*******************************************************************************/

var winReference = null;


// Open a window at a given position on the screen
function openPositionedWindow(url, name, width, height, x, y, status, scrollbars, moreProperties, openerName) {

   // ie 4.5 and 5.0 mac - windows are 2 pixels too short; if a statusbar is used, the window will be an additional 15 pixels short
   var agent = navigator.userAgent.toLowerCase();
   if (agent.indexOf("mac") != -1 && agent.indexOf("msie") != -1 && (agent.indexOf("msie 4") != -1 || agent.indexOf("msie 5.0") != -1) ) {
      height += (status) ? 17 : 2;
   }

   // Adjust width if scrollbars are used (pc places scrollbars inside the content area; mac outside)
   width += (scrollbars != '' && scrollbars != null && agent.indexOf("mac") == -1) ? 16 : 0;

   var properties = 'width=' + width + ',height=' + height + ',screenX=' + x + ',screenY=' + y + ',left=' + x + ',top=' + y + ((status) ? ',status' : '') + ',scrollbars' + ((scrollbars) ? '' : '=no') + ((moreProperties) ? ',' + moreProperties : '');
   var reference = openWindow(url, name, properties, openerName);

   // resize window in ie if we can resize in ns; very messy
   // commented out because openPositionedWindow() doesn't set the resizable attribute
   // left in for reference
   /*if (resizable && agent.indexOf("msie") != -1) {
      if (agent.indexOf("mac") != -1) {
         height += (status) ? 15 : 2;
         if (parseFloat(navigator.appVersion) > 5) width -= 11;
      }
      else {
         height += (status) ? 49 : 31;
         width += 13;
      }
      setTimeout('if (reference != null && !reference.closed) reference.resizeTo(' + width + ',' + height + ');', 150);
   }*/

   return reference;
}


// Open a window at the center of the screen
function openCenteredWindow(url, name, width, height, status, scrollbars, moreProperties, openerName) {
   var x, y = 0;
   if (screen) {
      x = (screen.availWidth - width) / 2;
      y = (screen.availHeight - height) / 2;
   }
   if (!status) status = '';
   if (!openerName) openerName = '';
   var reference = openPositionedWindow(url, name, width, height, x, y, status, scrollbars, moreProperties, openerName);
   return reference;
}


// Open a window at the center of the parent window
function openCenteredOnOpenerWindow(url, name, width, height, status, scrollbars, moreProperties, openerName) {
   var centerX = 0;
   var centerY = 0;
   if (window.screenX != null && window.outerWidth) {
      centerX = window.screenX + (window.outerWidth / 2);
      centerY = window.screenY + (window.outerHeight / 2);
   }
   else if (window.screenLeft) {
      if (document.documentElement) {
         centerX = window.screenLeft + (document.documentElement.offsetWidth / 2);
         centerY = window.screenTop + (document.documentElement.offsetHeight / 2);
      }
      else if (document.body && document.body.offsetWidth) {
         centerX = window.screenLeft + (document.body.offsetWidth / 2);
         centerY = window.screenTop + (document.body.offsetHeight / 2);
      }
   }

   if (centerX == 0) {
      openCenteredWindow(url, name, width, height, status, scrollbars, moreProperties, openerName);
   }
   var x = parseInt(centerX - (width / 2));
   var y = parseInt(centerY - (height / 2));
   if (!status) status = '';
   if (!openerName) openerName = '';
   var reference = openPositionedWindow(url, name, width, height, x, y, status, scrollbars, moreProperties, openerName);
   return reference;
}


// Open a full-screen window (different from IE's fullscreen option)
function openMaxedWindow(url, name, scrollbars, openerName) {
   var x, y = 0;
   var width  = 600;
   var height = 800;
   if (screen) {
      if (screen.availLeft) {
         x = screen.availLeft;
         y = screen.availTop;
      }
      width  = screen.availWidth - 6;
      height = screen.availHeight - 29;
   }
   var reference = openPositionedWindow(url, name, width, height, x, y, false, scrollbars, openerName);
   return reference;
}


// Open a full-chrome (all GUI elements) window
// This is like using a target="_blank" in a normal link but allows focussing the window
function openFullChromeWindow(url, name, openerName) {
   return openWindow(url, name, 'directories,location,menubar,resizable,scrollbars,status,toolbar');
}


// Open a sized full-chrome (all GUI elements) window
function openSizedFullChromeWindow(url, name, width, height, openerName) {
   return openCenteredWindow(url, name, width, height, true, true, 'directories,location,menubar,resizable,toolbar', openerName)
}


// Core utility function that actually creates the window and gives focus to it
function openWindow(url, name, properties, openerName) {

   // ie4.x pc can't give focus to windows containing documents from a different domain
   // in this case, initially load a local interstisial page to allow focussing before loading final url
   var agent = navigator.userAgent.toLowerCase();
   if (agent.indexOf("msie") != -1 && parseInt(navigator.appVersion) == 4 && agent.indexOf("msie 5") == -1 && agent.indexOf("msie5") == -1 && agent.indexOf("win") != -1 && url.indexOf('http://') == 0) {
      winReference = window.open('about:blank', name, properties);

      setTimeout('if (winReference && !winReference.closed) winReference.location.replace("' + url + '")', 300);
   }
   else {
      winReference = window.open(url, name, properties);
   }

   // ie doesn't like giving focus immediately (to new window in 4.5 on mac; to existing ones in 5 on pc)
   setTimeout('if (winReference && !winReference.closed) winReference.focus()', 200);

   if (openerName) self.name = openerName;
   return winReference;
}

function openx(url) {
   return openWindow(url, 'noaoffsite', 'directories,location,menubar,resizable,scrollbars,status,toolbar');
}

function openX(url) {
   return openWindow(url, 'noaoffsite', 'directories,location,menubar,resizable,scrollbars,status,toolbar');
}

/*******************************************************************************
   Modal Dialog controls
*******************************************************************************/

// Close a dialog
// Call from onunload event handler of any page that can create a dialog
function closeDialog(dialog) {
   if (dialog && dialog.closed != true) dialog.close();
}


// Close parent popup
// Call from onload event handler of any page that could be created from a dialog
function closeParentDialog() {
   if (top.opener && isWindowPopup(top.opener)) {
      root = top.opener.top.opener;
      top.opener.close();
      top.opener = root;
   }
}


// Check if a window is a popup
function isWindowPopup(win) {
   return ((win.opener) ? true : false);
}

// Validate a poll
function validatePoll()
{
   pollForm = document.forms["poll"];
   var checked = false;
   for (i =0; i < pollForm.elements["poll_response"].length; i++)
   {
      if (pollForm.elements["poll_response"][i].checked)
      {
         checked = true;
      }
   }

   if (checked == true)
   {
      pollForm.submit();
   } else
   {
      alert("Please select a poll response and resubmit your vote.");
   }
}


/*********************************
   utils.js for Nintendo.com
   js code for Nintendo.com redesign prototype
   code by Byron Tredwell (byron(AT)blastradius.com)
*********************************/

//simple object validation
function check(e){
   if(typeof e == "string"){elm = getElm(e);}else{elm = e;}
   if(elm == null || typeof elm != "object") throw Error("Element "+e+" does not exist. It is type "+typeof elm);
   return elm;
}

function getElm(e,f){
   if (f == null) f = self;
   return f.document.getElementById(e);
}

/***
  GET/CREATE/DELETE/WRITE
                       ***/

function createElm(t,id,p){
   if (p == null)
      p = document.body;
   p = check(p);
   var elm = document.createElement(t);
   if (id != null && id != "") elm.id = id;
         p.appendChild(elm);
    return elm;
}

function deleteElm(e){e = check(e); e.parentNode.removeChild(e);}

function clearElm(e){
   e = check(e);
   while (e.hasChildNodes()) { e.removeChild(e.lastChild) };
}

function writeTo(e,c){
e = check(e);
if(c == null) c = " ";
 var tNode = document.createTextNode(c);
 e.appendChild(tNode);
}

// portions of this function ripped from http://wsabstract.com/javatutors/dynamiccontent4.shtml by Rey Nunez
function writeHTML(e,c){
 e = check(e);
 if(c == null) c = "<br />";
 if(document.innerHTML != -1){
  e.innerHTML = c;
 }else if(document.createRange != -1){
  rng = document.createRange();
  rng.setStartBefore(e);
  htmlFrag = rng.createContextualFragment(c);
  clearElm(e);
  e.appendChild(htmlFrag);
 }else{
  e.document.open();
  e.document.writeln(c);
  e.document.close();
 }
}

/***
   CLIPPING
           ***/
function setClip(e,t,r,b,l)
{
  if(t==null) t=0;
  if(r==null) r=0;
  if(b==null) b=0;
  if(l==null) l=0;
  e.style.clip='rect('+t+'px '+r+'px '+b+'px '+l+'px)';
}

function getClip(e,s)
{
   var clipv = e.style.clip.split('rect(')[1].split(')')[0].split(' ');
   for(i=0;i<clipv.length;i++){
      clipv[i]= parseInt(clipv[i]);
   }
   switch (s){
      case ('t') : return clipv[0]; break;
      case ('r') : return clipv[1]; break;
      case ('b') : return clipv[2]; break;
      case ('l') : return clipv[3]; break;
      default : return clipv; break;
   }
}
function clipBy(e,t,r,b,l)
{
   if(t==null) t=0;
   if(r==null) r=0;
   if(b==null) b=0;
   if(l==null) l=0;
   setClip(e, parseInt(getClip(e,'t') + t), parseInt(getClip(e,'r') + r), parseInt(getClip(e,'b') + b), parseInt(getClip(e,'l') + l));
}


/***
   SIZE
       ***/

function setWidth(e,w){if(w==null) w=0; e = check(e); e.style.width=w+"px"; }
function setHeight(e,h){if(h==null) h=0; e = check(e); e.style.height=h+"px";}
function getWidth(e){e = check(e); return parseInt(e.style.width); }
function getHeight(e){e = check(e); return parseInt(e.style.height);}
function growBy(e,w,h){if(w==null) w=0; if(h==null) h=0; setWidth(e,getWidth(e)+w); setHeight(e,getHeight(e)+h);}
function growTo(e,w,h){setWidth(e,w); setHeight(e,h);}

/***
  POSISTION ADJUST
                ***/

function setX(e,x){if(!x) x=0; e = check(e); e.style.left=x+"px"; }
function setY(e,y){if(!y) y=0; e = check(e); e.style.top=y+"px"; /* alert(y + " - " + e.style.top); */ }
function setR(e,r){if(!r) r=0; e = check(e); e.style.right=r+"px"; }
function setB(e,b){if(!b) b=0; e = check(e); e.style.bottom=b+"px"; }
function setZ(e,z){if(!z) z=1; e = check(e); e.style.zIndex=z; }

function getX(e){e = check(e); return parseInt(e.style.left); }
function getY(e){e = check(e); return parseInt(e.style.top); }
function getR(e){e = check(e); return parseInt(e.style.right); }
function getB(e){e = check(e); return parseInt(e.style.bottom); }
function getZ(e){e = check(e); return parseInt(e.style.zIndex); }
function moveBy(e,x,y,z){e = check(e); if(!x) x=0; if(!y) y=0; if(!z) z=0; setX(e,getX(e)+x); setY(e,getY(e)+y); setZ(e,getZ(e)+z);}
function moveTo(e,x,y,z){setX(e,x); setY(e,y); setZ(e,z)}

/***
  OPACITY
         ***/
function setOpacity(e,op){
  e = check(e);
  if(op==null) op=100;
  if(isNaN(op)) op = parseFloat(op);
  if(op<=1) op=op*100;
  e.style.filter = "alpha(opacity="+op+")";
  op = op/100;
  e.style.MozOpacity = op;
  e.style.KhtmlOpacity = op;
  e.style.opacity = op;
}

/***
  GET OFFSET PROPERTY
                ***/
function getOffsetProperty(elm, property, relativeElmID) {
   var offset = 0;
   var element = check(elm);
   if(typeof element == "undefined" || element == null)
   {
      return "NaN";
   }
   var relativeElm = document.getElementById(relativeElmID);

   if(relativeElm == null || typeof relativeElm == "undefined")
      relativeElm = document.body;
   do {
      offset += eval('element.offset' + property);
      element = element.offsetParent;
   } while (element != relativeElm && element != null);
   return parseInt(offset);
}

/***
  ADD AND REMOVE EVENT LISTENERS
                ***/

function addListener(elm,event,func){
  if(document.attachEvent){
    elm.attachEvent("on"+event, func);
  }else if(document.addEventListener){
    elm.addEventListener(event, func, true);
  }else{
      eval(elm+".on"+event+"="+func);
  }
}

function removeListener(elm,event,func){
  if(document.detachEvent){
    elm.detachEvent("on"+event, func);
  }else if(document.removeEventListener){
    elm.removeEventListener(event, func, true);
  }else{
      eval(elm+".on"+event+"= function(){return false;}");
  }
}

function stopBubbleStopReturn(event){
 if(event.stopPropagation){
    event.stopPropagation();
    event.preventDefault();
 }else  if(event.cancelBubble == false || event.returnValue == true){
    event.cancelBubble = true;
    event.returnValue = false;
 }
}

/***
  GET THE WINDOW SCROLL
                ***/

function getScrollTop(win) {
   var scrollTop = 0;
   if (win.pageYOffset) {
      scrollTop = win.pageYOffset;
   }
   else if (win.document.documentElement && win.document.documentElement.scrollTop) {
      scrollTop = win.document.documentElement.scrollTop;
   }
   else if (win.document.body) {
      scrollTop = win.document.body.scrollTop;
   }
   return scrollTop;
}

function encodeUrl(url) {
    return escape(url).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27');
}

/*********************************
   nav.js for Nintendo.com
   js code for Nintendo.com redesign prototype
   code by Chad Lindstrom (chad.lindstrom(AT)blastradius.com)
*********************************/
var currentflyout = null;

function toggleMenuLayer(layer,mark,parent,left,top) {
   layer = getElm(layer);
   if(!layer)
      return;
   if(isNaN(left) == true)
      left = 0;
   if(isNaN(top) == true)
      top = 0;

   if(currentflyout && currentflyout != layer && currentflyout.style.display == "block")
   {
      currentflyout.style.display = "none"
      var m = currentflyout.mark;
      m.className = m.className.substring(0,m.className.indexOf(" hover"));
   }
   mark = check(mark);
   currentflyout = layer;
   layer.mark = mark;
   //layer.style.top  = (getOffsetProperty(mark, "Top",parent) + mark.offsetHeight + top) +"px";
   layer.style.top  = (getOffsetProperty(mark, "Top",parent)  + top) - 9  +"px";
   layer.style.left = (getOffsetProperty(mark, "Left",parent) + left) + 1 +"px";

   if(layer.style.display == "block")
   {
      layer.style.display = "none";
      mark.className = mark.className.substring(0,mark.className.indexOf(" hover"));
      //safariFlashFix("show");
   }else{
      layer.style.display = "block";
      mark.className = mark.className +" hover";
      if(getElm(layer.id+"BG"))
      {
         var bg = getElm(layer.id+"BG");
         bg.style.height = layer.offsetHeight +"px";
         if(isMac && !isSafari)
            setOpacity(bg,100);
      }
      //safariFlashFix("hide");
   }
}

function showMenuLayer(layer,mark,parent,left,top) {
   if(currentflyout && currentflyout.style.display == "block") {
      currentflyout.style.display = "none";
      var m = currentflyout.mark;
      m.className = m.className.substring(0,m.className.indexOf(" hover"));
   }
   keepUp(getElm(layer));
   toggleMenuLayer(layer,mark,parent,left,top);
}

function delayHide(elm){
      if(typeof elm != "object")
         elm = getElm(elm);
      elm.keepMeUp = false;
      setTimeout('hideMenuLayer()',100);
}

function keepUp(elm){
   if(!elm)
      return;
      elm.keepMeUp = true;
}

function hideMenuLayer(){
      if(!currentflyout)
         return;
      if(!currentflyout.keepMeUp)
      {
         currentflyout.style.display = "none";
         var mark = currentflyout.mark;
         mark.className = mark.className.substring(0,mark.className.indexOf(" hover"));
         currentflyout = null;
         //safariFlashFix("show");
      }
}
function getSwf(s){
   var idx = s.indexOf('?');
   if( idx > -1 ){
      return s.substring(0,idx);
   }
   return s;
}
function getNameValue(s){
   var nameValueArr = new Array();

   var idx = s.indexOf('?');
   if( idx > -1 ){
      var tmp = s.substring(idx,s.length);
      var tmpPairs = tmp.split("&");
      for(var i = 0; i < tmpPairs.length; i++){
         var nameValue = tmpPairs[i].split("=");
         nameValueArr.push( {'name': nameValue[0], 'value': nameValue[1]});
      }
   }
   return nameValueArr;
}

}

/*
     FILE ARCHIVED ON 21:17:43 Dec 05, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 00:36:53 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.323
  captures_list: 0.406
  exclusion.robots: 0.031
  exclusion.robots.policy: 0.024
  esindex: 0.005
  cdx.remote: 9.568
  LoadShardBlock: 204.033 (6)
  PetaboxLoader3.datanode: 213.115 (7)
  load_resource: 118.389
  PetaboxLoader3.resolve: 87.594
*/