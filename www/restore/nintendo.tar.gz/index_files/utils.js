var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
/*********************************
   utils.js for Nintendo.com
   js code for Nintendo.com redesign prototype
   code by Byron Tredwell (byron(AT)blastradius.com)
*********************************/

//simple object validation
function check(e){
   if(typeof e == "string"){elm = getElm(e);}else{elm = e;}
   if(elm == null || typeof elm != "object") throw Error("Element "+e+" does not exist. It is type "+typeof elm);
   return elm;
}

function getElm(e,f){
   if (f == null) f = self;
   return f.document.getElementById(e);
}

/***
  GET/CREATE/DELETE/WRITE
                       ***/

function createElm(t,id,p){
   if (p == null)
      p = document.body;
   p = check(p);
   var elm = document.createElement(t);
   if (id != null && id != "") elm.id = id;
         p.appendChild(elm);
    return elm;
}

function deleteElm(e){e = check(e); e.parentNode.removeChild(e);}

function clearElm(e){
   e = check(e);
   while (e.hasChildNodes()) { e.removeChild(e.lastChild) };
}

function writeTo(e,c){
e = check(e);
if(c == null) c = " ";
 var tNode = document.createTextNode(c);
 e.appendChild(tNode);
}

// portions of this function ripped from http://wsabstract.com/javatutors/dynamiccontent4.shtml by Rey Nunez
function writeHTML(e,c){
 e = check(e);
 if(c == null) c = "<br />";
 if(document.innerHTML != -1){
  e.innerHTML = c;
 }else if(document.createRange != -1){
  rng = document.createRange();
  rng.setStartBefore(e);
  htmlFrag = rng.createContextualFragment(c);
  clearElm(e);
  e.appendChild(htmlFrag);
 }else{
  e.document.open();
  e.document.writeln(c);
  e.document.close();
 }
}

/***
   CLIPPING
           ***/
function setClip(e,t,r,b,l)
{
  if(t==null) t=0;
  if(r==null) r=0;
  if(b==null) b=0;
  if(l==null) l=0;
  e.style.clip='rect('+t+'px '+r+'px '+b+'px '+l+'px)';
}

function getClip(e,s)
{
   var clipv = e.style.clip.split('rect(')[1].split(')')[0].split(' ');
   for(i=0;i<clipv.length;i++){
      clipv[i]= parseInt(clipv[i]);
   }
   switch (s){
      case ('t') : return clipv[0]; break;
      case ('r') : return clipv[1]; break;
      case ('b') : return clipv[2]; break;
      case ('l') : return clipv[3]; break;
      default : return clipv; break;
   }
}
function clipBy(e,t,r,b,l)
{
   if(t==null) t=0;
   if(r==null) r=0;
   if(b==null) b=0;
   if(l==null) l=0;
   setClip(e, parseInt(getClip(e,'t') + t), parseInt(getClip(e,'r') + r), parseInt(getClip(e,'b') + b), parseInt(getClip(e,'l') + l));
}


/***
   SIZE
       ***/

function setWidth(e,w){if(w==null) w=0; e = check(e); e.style.width=w+"px"; }
function setHeight(e,h){if(h==null) h=0; e = check(e); e.style.height=h+"px";}
function getWidth(e){e = check(e); return parseInt(e.style.width); }
function getHeight(e){e = check(e); return parseInt(e.style.height);}
function growBy(e,w,h){if(w==null) w=0; if(h==null) h=0; setWidth(e,getWidth(e)+w); setHeight(e,getHeight(e)+h);}
function growTo(e,w,h){setWidth(e,w); setHeight(e,h);}

/***
  POSISTION ADJUST
                ***/

function setX(e,x){if(!x) x=0; e = check(e); e.style.left=x+"px"; }
function setY(e,y){if(!y) y=0; e = check(e); e.style.top=y+"px"; /* alert(y + " - " + e.style.top); */ }
function setR(e,r){if(!r) r=0; e = check(e); e.style.right=r+"px"; }
function setB(e,b){if(!b) b=0; e = check(e); e.style.bottom=b+"px"; }
function setZ(e,z){if(!z) z=1; e = check(e); e.style.zIndex=z; }

function getX(e){e = check(e); return parseInt(e.style.left); }
function getY(e){e = check(e); return parseInt(e.style.top); }
function getR(e){e = check(e); return parseInt(e.style.right); }
function getB(e){e = check(e); return parseInt(e.style.bottom); }
function getZ(e){e = check(e); return parseInt(e.style.zIndex); }
function moveBy(e,x,y,z){e = check(e); if(!x) x=0; if(!y) y=0; if(!z) z=0; setX(e,getX(e)+x); setY(e,getY(e)+y); setZ(e,getZ(e)+z);}
function moveTo(e,x,y,z){setX(e,x); setY(e,y); setZ(e,z)}

/***
  OPACITY
         ***/
function setOpacity(e,op){
  e = check(e);
  if(op==null) op=100;
  if(isNaN(op)) op = parseFloat(op);
  if(op<=1) op=op*100;
  e.style.filter = "alpha(opacity="+op+")";
  op = op/100;
  e.style.MozOpacity = op;
  e.style.KhtmlOpacity = op;
  e.style.opacity = op;
}

/***
  GET OFFSET PROPERTY
                ***/
function getOffsetProperty(elm, property, relativeElmID) {
   var offset = 0;
   var element = check(elm);
   if(typeof element == "undefined" || element == null)
   {
      return "NaN";
   }
   var relativeElm = document.getElementById(relativeElmID);

   if(relativeElm == null || typeof relativeElm == "undefined")
      relativeElm = document.body;
   do {
      offset += eval('element.offset' + property);
      element = element.offsetParent;
   } while (element != relativeElm && element != null);
   return parseInt(offset);
}

/***
  ADD AND REMOVE EVENT LISTENERS
                ***/

function addListener(elm,event,func){
  if(document.attachEvent){
    elm.attachEvent("on"+event, func);
  }else if(document.addEventListener){
    elm.addEventListener(event, func, true);
  }else{
      eval(elm+".on"+event+"="+func);
  }
}

function removeListener(elm,event,func){
  if(document.detachEvent){
    elm.detachEvent("on"+event, func);
  }else if(document.removeEventListener){
    elm.removeEventListener(event, func, true);
  }else{
      eval(elm+".on"+event+"= function(){return false;}");
  }
}

function stopBubbleStopReturn(event){
 if(event.stopPropagation){
    event.stopPropagation();
    event.preventDefault();
 }else  if(event.cancelBubble == false || event.returnValue == true){
    event.cancelBubble = true;
    event.returnValue = false;
 }
}

/***
  GET THE WINDOW SCROLL
                ***/

function getScrollTop(win) {
   var scrollTop = 0;
   if (win.pageYOffset) {
      scrollTop = win.pageYOffset;
   }
   else if (win.document.documentElement && win.document.documentElement.scrollTop) {
      scrollTop = win.document.documentElement.scrollTop;
   }
   else if (win.document.body) {
      scrollTop = win.document.body.scrollTop;
   }
   return scrollTop;
}

function encodeUrl(url) {
    return escape(url).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27');
}
}

/*
     FILE ARCHIVED ON 07:32:18 Nov 26, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 00:36:52 Jun 12, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.496
  load_resource: 90.7
  PetaboxLoader3.resolve: 71.647
  PetaboxLoader3.datanode: 18.23
*/